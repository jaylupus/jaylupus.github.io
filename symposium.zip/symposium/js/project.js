$(document).ready(function(){
	$('img').hover(
		function(e){
			console.log(e);
			$(this).parent().animate({opacity:1}, 500);
		},
		function(e){
			$(this).parent().animate({opacity:0}, 500);
		}
	);
});